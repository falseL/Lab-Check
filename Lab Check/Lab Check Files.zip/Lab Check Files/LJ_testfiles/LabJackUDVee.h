//LabJackUDVee.h
//Special header file for Agilent VEE
#ifndef LJHEADER_H
#define LJHEADER_H
// the version of this driver.  Call GetVersion() to determine the version of the DLL you have.
// It should match this number, otherwise your .h and DLL's are from different versions.
#define DRIVER_VERSION 2.56
#define LJ_HANDLE long
#define LJ_ERROR long
#ifdef  __cplusplus
extern "C"
{
#endif 
// the S form of these functions (the ones with S at the end) take strings instead of numerics for places where constants
// would normally be used.  This allows languages that can't include this header file to still use defined constants rather
// than hard coded numbers.
LJ_ERROR _stdcall ListAll(long DeviceType, long ConnectionType, long *pNumFound, long *pSerialNumbers, long *pIDs, double *pAddresses);
LJ_ERROR _stdcall ListAllS(const char *pDeviceType, const char *pConnectionType, long *pNumFound, long *pSerialNumbers, long *pIDs, double *pAddresses);
// returns all the devices found of a given device type and connection type.  Currently only USB is supported.  pSerialNumbers, pIDs and
// pAddresses must be arrays of the given type at least 128 elements in size. pNumFound is a single element and will tell you how many
// of those 128 elements have valid data (and therefore the number of units found. With pAddresses you'll probably want
// to use the DoubleToStringAddress() function below to convert.
LJ_ERROR _stdcall OpenLabJack(long DeviceType, long ConnectionType, const char *pAddress, long FirstFound, LJ_HANDLE *pHandle);
LJ_ERROR _stdcall OpenLabJackS(const char *pDeviceType, const char *pConnectionType, const char *pAddress, long FirstFound, LJ_HANDLE *pHandle);
// must be called before working with a device
// DeviceType = the type of LabJack device to open (codes listed above)
// ConnectionType = how to connect to the device, USB or Ethernet presently.  
//     Ethernet only currently supported on the UE9.
// Address = either the ID (if USB), or the IP address.  Note this is a string for either.
// FirstFound = if true, then ignore Address and find the first available labjack.
// pHandle = the handle to use for subsequent functions on this device, or 0 if failed
//
// this function returns 0 if success and a handle to the open labjack, or an errorcode if failed
LJ_ERROR _stdcall AddRequest(LJ_HANDLE Handle, long IOType, long Channel, double Value, long x1, double UserData);
LJ_ERROR _stdcall AddRequestS(LJ_HANDLE Handle, const char *pIOType, long Channel, double Value, long x1, double UserData);
LJ_ERROR _stdcall AddRequestSS(LJ_HANDLE Handle, const char *pIOType, const char *pChannel, double Value, long x1, double UserData);
// function to add to the list of things to do with the next call to DoRead()
// Handle: a handle returned by OpenLabJack()
// IOType: The type of data request (see constants above)
// Channel: The channel # on the particular IOType
// Value: For output channels, the value to set to
// X1: optional parameters used by some IOTypes.  
// UserData: data that is kept with the request and returned with the GetFirst and GetNextResult() functions
// returns 0 if success, errorcode if not (most likely handle not found)
// NOTE: when you call AddRequest on a particular Handle, all previous data is erased and cannot be retrieved
// by GetResult() until read again.  This is on a device by device basis, so you can call AddRequest() with a different
// handle while a device is busy performing its I/O.
// the long version is used by languages that can't cast a pointer into a double and should only be used in such situations
LJ_ERROR _stdcall Go(void);
// called once AddRequest has specified all the items to do.  This function actually does all those things on all devices.
// takes no parameters.  Returns 0 if success, errorcode if not (currently never returns an error, as errors in reading
// individual items are returned when GetResult() is called
LJ_ERROR _stdcall GoOne(LJ_HANDLE Handle);
// same as above, but only does requests on the given handle
LJ_ERROR _stdcall eGet(LJ_HANDLE Handle, long IOType, long Channel, double *pValue, long x1);
LJ_ERROR _stdcall eGetS(LJ_HANDLE Handle, const char *pIOType, long Channel, double *pValue, long x1);
LJ_ERROR _stdcall eGetSS(LJ_HANDLE Handle, const char *pIOType, const char *pChannel, double *pValue, long x1);
LJ_ERROR _stdcall ePut(LJ_HANDLE Handle, long IOType, long Channel, double Value, long x1);
LJ_ERROR _stdcall ePutS(LJ_HANDLE Handle, const char *pIOType, long Channel, double Value, long x1);
LJ_ERROR _stdcall ePutSS(LJ_HANDLE Handle, const char *pIOType, const char *pChannel, double Value, long x1);
// these functions do AddRequest, Go, and GetResult in one step.  The Get versions are designed for inputs or retrieving parameters
// as it takes a pointer to a double where the result is placed, but can be used for outputs if pValue is preset to the 
// desired value.  This is also useful for things like StreamRead where a value is required to be input and a value is
// returned.  The Put versions are designed for outputs or setting configuration parameters and won't return anything but the error code.
// Internally, all the put versions do is call the get function with a pointer set for you.
// you can repeditively call Go() and GoOne() along with GetResult() to repeat the same requests.  Once you call AddRequest() 
// once on a particular device, it will clear out the requests on that particular device.  
// NOTE: be careful when using multiple devices and Go(): AddRequest() only clears out the request list on the device handle 
// provided.  If, for example, you perform run two requests, one on each of two different devices, and then add a new request on 
// one device but not the other and then call Go(), the original request on the second device will be performed again
LJ_ERROR _stdcall GetResult(LJ_HANDLE Handle, long IOType, long Channel, double *pValue);
LJ_ERROR _stdcall GetResultS(LJ_HANDLE Handle, const char *pIOType, long Channel, double *pValue);
LJ_ERROR _stdcall GetResultSS(LJ_HANDLE Handle, const char *pIOType, const char *pChannel, double *pValue);
// called to retrieve data and error codes for the things done in Go().  Typically this should be called
// for each element passed with AddRequest, but outputs can be skipped if errorcodes not needed. 
// Handle, IOType, Channel: these should match the parameters passed in AddRequest to retrieve the result for
//     that particular item
// pValue = value retrieved for that item.
// returns 0 if success, LJE_NODATA if no data available for the particular Handle,IOType, and Channel specified,
// or the error code for the particular action performed.
// the long version is used by languages that can't cast a pointer into a double and should only be used in such situations
LJ_ERROR _stdcall GetFirstResult(LJ_HANDLE Handle, long *pIOType, long *pChannel, double *pValue, long *px1, double *pUserData);
LJ_ERROR _stdcall GetNextResult(LJ_HANDLE Handle, long *pIOType, long *pChannel, double *pValue, long *px1, double *pUserData);
// these GetResult() type functions are designed for situations when you want to get all the results in order.  Call GetFirstResult()
// first to get the first result avialable for the given handle and the error code.  Then call GetNextResult() repeditively for
// subsequent requests. When either function returns LJE_NO_MORE_DATA_AVAILABLE, you're done.  Note that x1 and UserData are always 
// returned as well.  You can therefore use UserData as space for your own tracking information, or whatever else you may need.  
// Here's a sample of how a loop might work:
// err = GetFirstResult(..)
// while (!err)
// {
//    process result...
//    err = GetNextResult(..)
// }
LJ_ERROR _stdcall eAIN( long handle, long channelP, long channelN, double *voltage, long range, long resolution, long settling, long binary,  long reserved1, long reserved2);
LJ_ERROR _stdcall eDAC( long handle, long channel, double voltage, long binary, long reserved1, long reserved2);
LJ_ERROR _stdcall eDI( long handle, long channel, long *state);
LJ_ERROR _stdcall eDO( long handle, long channel, long state);
LJ_ERROR _stdcall eAddGoGet( long handle, long numRequests, long *aIOTypes, long *aChannels, double *aValues, long *aX1s, long *aRequestErrors, long *goError, long *aResultErrors);
LJ_ERROR _stdcall eTCConfig( long handle, long *aEnableTimers, long *aEnableCounters, long TCPinOffset, long TimerClockBaseIndex, long TimerClockDivisor, long *aTimerModes, double *aTimerValues, long reserved1, long reserved2);
LJ_ERROR _stdcall eTCValues( long handle, long *aReadTimers, long *aUpdateResetTimers, long *aReadCounters, long *aResetCounters, double *aTimerValues, double *aCounterValues, long reserved1, long reserved2);
// Prototypes for beta version of easy functions to make simple tasks easier.  
// *************************************************
// NOTE: This driver is completely thread safe.  With some very minor exceptions, you can call all these functions from 
// multiple threads at the same time and the driver will keep everything straight.  Because of this, you must call Add...(), 
// Go...() and Get...() from the same thread for a particular set of requests.  Internally the list of things to do and 
// results are split by thread.  This allows you to use multiple threads to make requests without accidently getting 
// data from one thread into another.  If you are Adding requests and then getting NO_DATA_AVAILABlE or similar error when
// Getting the results, then chances are you are running in different threads and don't realize this.
// SubNote: The driver tracks which thread a request is made in by the thread ID.  If you kill a thread and then create a new one
// it is possible for the new thread to have the same ID.  Its not really a problem if you call AddRequest first, but if you 
// did GetFirstResult on a new thread you may actually get data from the thread that already ended.
// SubNote: As mentioned, the list of requests and results is kept on a thread by thread basis.  Since the driver can't tell
// when a thread has ended, the results are kept in memory for that thread even though the thread is done (thus the reason for the 
// above mentioned subnote).  This is not a problem in general as the driver will clean it all up when its unloaded.  When it can
// be a problem is in situations where you are creating and destorying threads continuously.  This will result in the slow consumption
// of memory as requests on old threads are left behind.  Since each request only uses 44 bytes and as mentioned the ID's will
// eventually get recycled, it won't be a huge memory loss, but it will be there.  In general, even without this issue, we strongly 
// recommend against creating and destroying a lot of threads.  Its terribly slow and inefficient.  Use thread pools and other 
// techniques to keep new thread creation to a minimum.  This is what is done internally,
// **************************************************
// NOTE: Continuing on the thread safety issue, the one big exception to the thread safety of this driver is in the use of 
// the windows TerminateThread() function.  As it warns in the MSDN documentation, using TerminateThread() will kill the thread 
// without releasing any resources, and more importantly, releasing any synchronization objects.  If you TerminateThread() on a 
// thread that is currently in the middle of a call to this driver, you will more than likely leave a synchronization object open
// on the particular device and you will no longer be able to access the device from you application until you restart.  On some 
// devices, it can be worse.  On devices that have interprocess synchonization, such as the U12, calling TerminateThread() may
// kill all access to the device through this driver no matter which process is using it and even if you restart your application.
// Just avoid using TerminateThread()!  All device calls have a timeout, which defaults to 1 second, but is changeable.  Make sure
// when you are waiting for the driver that you wait at least as long as the timeout for it to finish.
// **************************************************
LJ_ERROR _stdcall ResetLabJack(LJ_HANDLE Handle); 
// useful functions:
// some config functions require IP address in a double instead of a string.  Here are some helpful functions:
LJ_ERROR _stdcall DoubleToStringAddress(double Number, char *pString, long HexDot);
// takes the given IP address in number notation (32 bit), and puts it into the String.  String should be 
// preallocated to at least 16 bytes (255.255.255.255\0)
LJ_ERROR _stdcall StringToDoubleAddress(const char *pString, double *pNumber, long HexDot);
// does the opposite, takes an IP address in dot notation and puts it into the given double
long _stdcall StringToConstant(const char *pString);
// converts the given string to the appropriate constant.  Used internally by the S functions, but could be useful if 
// you wanted to use the GetFirst/Next functions and couldn't use this header.  Then you could do a comparison on the 
// returned values:
// if (IOType == StringToConstant("LJ_ioGET_AIN")) 
// This function returns LJ_INVALID_CONSTANT if an invalid constant
void _stdcall ErrorToString(LJ_ERROR ErrorCode, char *pString);
// returns a string describing the given error code or an empty string if not found.  pString must be at least 256 chars in length
double _stdcall GetDriverVersion(void);
// returns the version # of this driver, the resultant number should match the number at the top of this header file
/*
// device types
const long LJ_dtUE9 = 9;
const long LJ_dtU3 = 3;
// connection types:
const long LJ_ctUSB = 1; // UE9 + U3
const long LJ_ctETHERNET = 2; // UE9 only
// Raw connection types are used to open a device but not communicate with it
// should only be used if the normal connection types fail and for testing.
// If a device is opened with the raw connection types, only LJ_ioRAW_OUT
// and LJ_ioRAW_IN io types should be used
const long LJ_ctUSB_RAW = 101; // UE9 + U3
const long LJ_ctETHERNET_RAW = 102; // UE9 only
// io types:
const long LJ_ioGET_AIN = 10; // UE9 + U3.  This is single ended version.  
const long LJ_ioGET_AIN_DIFF = 15; // U3 only.  Put second channel in x1.  If 32 is passed as x1, Vref will be added to the result. 
const long LJ_ioPUT_AIN_RANGE = 2000; // UE9
const long LJ_ioGET_AIN_RANGE = 2001; // UE9
// sets or reads the analog or digital mode of the FIO and EIO pins.  FIO is Channel 0-7, EIO 8-15
const long LJ_ioPUT_ANALOG_ENABLE_BIT = 2013; // U3 
const long LJ_ioGET_ANALOG_ENABLE_BIT = 2014; // U3 
// sets or reads the analog or digital mode of the FIO and EIO pins. Channel is starting 
// bit #, x1 is number of bits to read. The pins are set by passing a bitmask as a double
// for the value.  The first bit of the int that the double represents will be the setting 
// for the pin number sent into the channel variable. 
const long LJ_ioPUT_ANALOG_ENABLE_PORT = 2015; // U3 
const long LJ_ioGET_ANALOG_ENABLE_PORT = 2016; // U3
const long LJ_ioPUT_DAC = 20; // UE9 + U3
const long LJ_ioPUT_DAC_ENABLE = 2002; // UE9 + U3 (U3 on Channel 1 only)
const long LJ_ioGET_DAC_ENABLE = 2003; // UE9 + U3 (U3 on Channel 1 only)
const long LJ_ioGET_DIGITAL_BIT = 30; // UE9 + U3  // changes direction of bit to input as well
const long LJ_ioGET_DIGITAL_BIT_DIR = 31; // U3
const long LJ_ioGET_DIGITAL_BIT_STATE = 32; // does not change direction of bit, allowing readback of output
// channel is starting bit #, x1 is number of bits to read 
const long LJ_ioGET_DIGITAL_PORT = 35; // UE9 + U3  // changes direction of bits to input as well
const long LJ_ioGET_DIGITAL_PORT_DIR = 36; // U3
const long LJ_ioGET_DIGITAL_PORT_STATE = 37; // U3 does not change direction of bits, allowing readback of output
// digital put commands will set the specified digital line(s) to output
const long LJ_ioPUT_DIGITAL_BIT = 40; // UE9 + U3
// channel is starting bit #, value is output value, x1 is bits to write
const long LJ_ioPUT_DIGITAL_PORT = 45; // UE9 + U3
// Used to create a pause between two events in a U3 low-level feedback
// command.  For example, to create a 100 ms positive pulse on FIO0, add a
// request to set FIO0 high, add a request for a wait of 100000, add a
// request to set FIO0 low, then Go.  Channel is ignored.  Value is
// microseconds to wait and should range from 0 to 8388480.  The actual
// resolution of the wait is 128 microseconds.
const long LJ_ioPUT_WAIT = 70; // U3
// counter.  Input only.
const long LJ_ioGET_COUNTER = 50; // UE9 + U3
const long LJ_ioPUT_COUNTER_ENABLE = 2008; // UE9 + U3
const long LJ_ioGET_COUNTER_ENABLE = 2009; // UE9 + U3
// this will cause the designated counter to reset.  If you want to reset the counter with
// every read, you have to use this command every time.
const long LJ_ioPUT_COUNTER_RESET = 2012;  // UE9 + U3 
// on UE9: timer only used for input. Output Timers don't use these.  Only Channel used.
// on U3: Channel used (0 or 1).  
const long LJ_ioGET_TIMER = 60; // UE9 + U3
const long LJ_ioPUT_TIMER_VALUE = 2006; // UE9 + U3.  Value gets new value
const long LJ_ioPUT_TIMER_MODE = 2004; // UE9 + U3.  On both Value gets new mode.  
const long LJ_ioGET_TIMER_MODE = 2005; // UE9
// IOTypes for use with SHT sensor.  For LJ_ioSHT_GET_READING, a channel of LJ_chSHT_TEMP (5000) will 
// read temperature, and LJ_chSHT_RH (5001) will read humidity.  
// The LJ_ioSHT_DATA_CHANNEL and LJ_ioSHT_SCK_CHANNEL iotypes use the passed channel 
// to set the appropriate channel for the data and SCK lines for the SHT sensor. 
// Default digital channels are FIO0 for the data channel and FIO1 for the clock channel. 
const long LJ_ioSHT_GET_READING = 500; // UE9 + U3.
const long LJ_ioSHT_DATA_CHANNEL = 501; // UE9 + U3. Default is FIO0
const long LJ_ioSHT_CLOCK_CHANNEL = 502; // UE9 + U3. Default is FIO1
const long LJ_ioSPI_COMMUNICATION = 503;
// Set's the U3 to it's original configuration.  This means sending the following
// to the ConfigIO and TimerClockConfig low level functions
//
// ConfigIO
// Byte #
// 6       WriteMask       15      Write all parameters.
// 8       TimerCounterConfig      0       No timers/counters.  Offset=0.
// 9       DAC1Enable      0       DAC1 disabled.
// 10      FIOAnalog       0       FIO all digital.
// 11      EIOAnalog       0       EIO all digital.
// 
// 
// TimerClockConfig
// Byte #
// 8       TimerClockConfig        130     Set clock to 24 MHz.
// 9       TimerClockDivisor       0       Divisor = 0.
// 
const long LJ_ioPIN_CONFIGURATION_RESET = 2017; // U3
// the raw in/out are unusual, channel # corresponds to the particular comm port, which 
// depends on the device.  For example, on the UE9, 0 is main comm port, and 1 is the streaming comm.
// Make sure and pass a porter to a char buffer in x1, and the number of bytes desired in value.  A call 
// to GetResult will return the number of bytes actually read/written.  The max you can send out in one call
// is 512 bytes to the UE9 and 16384 bytes to the U3.
const long LJ_ioRAW_OUT = 100; // UE9 + U3
const long LJ_ioRAW_IN = 101; // UE9 + U3
// sets the default power up settings based on the current settings of the device AS THIS DLL KNOWS.  This last part
// basically means that you should set all parameters directly through this driver before calling this.  This writes 
// to flash which has a limited lifetime, so do not do this too often.  Rated endurance is 20,000 writes.
const long LJ_ioSET_DEFAULTS = 103; // U3
// requests to create the list of channels to stream.  Usually you will use the CLEAR_STREAM_CHANNELS request first, which
// will clear any existing channels, then use ADD_STREAM_CHANNEL multiple times to add your desired channels.  Some devices will 
// use value, x1 for other parameters such as gain.  Note that you can do CLEAR, and then all your ADDs in a single Go() as long
// as you add the requests in order.
const long LJ_ioADD_STREAM_CHANNEL = 200;
const long LJ_ioCLEAR_STREAM_CHANNELS = 201;
const long LJ_ioSTART_STREAM = 202;
const long LJ_ioSTOP_STREAM = 203;
// Get stream data has several options.  If you just want to get a single channel's data (if streaming multiple channels), you 
// can pass in the desired channel #, then the number of data points desired in Value, and a pointer to an array to put the 
// data into as X1.  This array needs to be an array of doubles. Therefore, the array needs to be 8 * number of 
// requested data points in byte length. What is returned depends on the StreamWaitMode.  If None, this function will only return 
// data available at the time of the call.  You therefore must call GetResult() for this function to retrieve the actually number 
// of points retreived.  If Pump or Sleep, it will return only when the appropriate number of points have been read or no 
// new points arrive within 100ms.  Since there is this timeout, you still need to use GetResult() to determine if the timeout 
// occured.  If AllOrNone, you again need to check GetResult.  
// You can also retreive the entire scan by passing LJ_chALL_CHANNELS.  In this case, the Value determines the number of SCANS 
// returned, and therefore, the array must be 8 * number of scans requested * number of channels in each scan.  Likewise
// GetResult() will return the number of scans, not the number of data points returned.
// Note: data is stored interleaved across all streaming channels.  In other words, if you are streaming two channels, 0 and 1, 
// and you request LJ_chALL_CHANNELS, you will get, Channel0, Channel1, Channel0, Channel1, etc.  Once you have requested the 
// data, any data returned is removed from the internal buffer, and the next request will give new data.
// Note: if reading the data channel by channel and not using LJ_chALL_CHANNELS, the data is not removed from the internal buffer
// until the data from the last channel in the scan is requested.  This means that if you are streaming three channels, 0, 1 and 2,
// and you request data from channel 0, then channel 1, then channel 0 again, the request for channel 0 the second time will 
// return the exact same amount of data.  Also note, that the amount of data that will be returned for each channel request will be
// the same until you've read the last channel in the scan, at which point your next block may be a different size.
// Note: although more convenient, requesting individual channels is slightly slower then using LJ_chALL_CHANNELS.  Since you 
// are probably going to have to split the data out anyway, we have saved you the trouble with this option.  
// Note: if you are only scanning one channel, the Channel parameter is ignored.
const long LJ_ioGET_STREAM_DATA = 204;
// since this driver has to start a thread to poll the hardware in stream mode, we give you the option of having this thread 
// call a user defined function after a block of data has been read.  To use, pass a pointer to the following function type as 
// Channel.  Pass 0 to turn this feature off.  X1 is a user definable value that is passed when the callback function is called. 
// Value is the number of scans before the callback occurs.  If 0, then the default is used, which varies depending on the 
// device and scan rate but typically results in the callback being called about every 10ms.
*/
/* example:
void StreamCallback(long ScansAvailable, double UserValue) 
{
... do stuff when a callback occurs (retrieve data for example)
}
...
tStreamCallback pCallback = StreamCallback;
AddRequest(Handle,LJ_ioSET_STREAM_CALLBACK,(long)pCallback,0,0,0);
...
*/
// NOTE: the callback function is called from a secondary worker thread that has no message pump.  Do not directly update any 
// windows controls from your callback as their is no message pump to do so.  On the same note, the driver stream buffer is locked
// during the callback function.  This means that while your callback function is running, you cannot do a GetStreamData or any 
// other stream function from a DIFFERENT thread.  You can of course do getstreamdata from the callback function.  You don't really
// have to worry about this much as any other thread trying to do GetStreamData or other function will simply stall until your 
// callback is complete and the lock released.  Where you will run into trouble is if your callback function waits on another thread
// that is trying to do a stream function.  Note this applies on a device by device basis.
/*
typedef void (*tStreamCallback)(long ScansAvailable, long UserValue);
const long LJ_ioSET_STREAM_CALLBACK = 205;
// U3 only:
// Channel = 0 buzz for a count, Channel = 1 buzz continuous
// Value is the Period
// X1 is the toggle count when channel = 0
const long LJ_ioBUZZER = 300; // U3 
// Used to access calibration and user data.  The address of an array is passed in as x1.
// For the UE9, a 1024 byte buffer is passed for both the user data and cal constant 
// functions.  For the U3, a 96 byte buffer is passed in for the cal constants, and a 
// 256 byte buffer for user data. The calibration constants are passed in and read 
// as doubles. The layout of the cal constants is defined in the users guide for the device. 
// When the LJ_ioPUT_CAL_CONSTANTS iotype is used, a special value must be passed in to 
// the channel and value variables to prevent calibration data from being erased accidentily. 
const long LJ_ioPUT_CAL_CONSTANTS = 400;
const long LJ_ioGET_CAL_CONSTANTS = 401;
const long LJ_ioPUT_USER_MEM = 402;
const long LJ_ioGET_USER_MEM = 403;
// config iotypes:
const long LJ_ioPUT_CONFIG = 1000; // UE9 + U3
const long LJ_ioGET_CONFIG = 1001; // UE9 + U3
// channel numbers used for CONFIG types:
// UE9 + U3
const long LJ_chLOCALID = 0; // UE9 + U3
const long LJ_chHARDWARE_VERSION = 10; // UE9 + U3 (Read Only)
const long LJ_chSERIAL_NUMBER = 12; // UE9 + U3 (Read Only)
const long LJ_chFIRMWARE_VERSION = 11; // UE9 + U3 (Read Only)
const long LJ_chBOOTLOADER_VERSION = 15; // UE9 + U3 (Read Only)
// UE9 specific:
const long LJ_chCOMM_POWER_LEVEL = 1; //UE9
const long LJ_chIP_ADDRESS = 2; //UE9
const long LJ_chGATEWAY = 3; //UE9
const long LJ_chSUBNET = 4; //UE9
const long LJ_chPORTA = 5; //UE9
const long LJ_chPORTB = 6; //UE9
const long LJ_chDHCP = 7; //UE9
const long LJ_chPRODUCTID = 8; //UE9
const long LJ_chMACADDRESS = 9; //UE9
const long LJ_chCOMM_FIRMWARE_VERSION = 11;  
const long LJ_chCONTROL_POWER_LEVEL = 13; //UE9 
const long LJ_chCONTROL_FIRMWARE_VERSION = 14; //UE9 (Read Only)
const long LJ_chCONTROL_BOOTLOADER_VERSION = 15; //UE9 (Read Only)
const long LJ_chCONTROL_RESET_SOURCE = 16; //UE9 (Read Only)
const long LJ_chUE9_PRO = 19; // UE9 (Read Only)
// U3 only:
// sets the state of the LED 
const long LJ_chLED_STATE = 17; // U3   value = LED state
const long LJ_chSDA_SCL = 18; // U3   enable / disable SDA/SCL as digital I/O
// timer/counter related
const long LJ_chNUMBER_TIMERS_ENABLED = 1000; // UE9 + U3
const long LJ_chTIMER_CLOCK_BASE = 1001; // UE9 + U3
const long LJ_chTIMER_CLOCK_DIVISOR = 1002; // UE9 + U3
const long LJ_chTIMER_COUNTER_PIN_OFFSET = 1003; // U3
// AIn related
const long LJ_chAIN_RESOLUTION = 2000; // ue9 + u3
const long LJ_chAIN_SETTLING_TIME = 2001; // ue9 + u3
const long LJ_chAIN_BINARY = 2002; // ue9 + u3
// DAC related
const long LJ_chDAC_BINARY = 3000; // ue9 + u3
// SHT related
const long LJ_chSHT_TEMP = 5000; // ue9 + u3
const long LJ_chSHT_RH = 5001; // ue9 + u3
// SPI related
const long LJ_chSPI_AUTO_CS = 5100; // UE9
const long LJ_chSPI_DISABLE_DIR_CONFIG = 5101; // UE9
const long LJ_chSPI_MODE = 5102; // UE9
const long LJ_chSPI_CLOCK_FACTOR = 5103; // UE9
const long LJ_chSPI_MOSI_PINNUM = 5104; // UE9
const long LJ_chSPI_MISO_PINNUM = 5105; // UE9
const long LJ_chSPI_CLK_PINNUM = 5106; // UE9
const long LJ_chSPI_CS_PINNUM = 5107; // UE9
// stream related.  Note, Putting to any of these values will stop any running streams.
const long LJ_chSTREAM_SCAN_FREQUENCY = 4000;
const long LJ_chSTREAM_BUFFER_SIZE = 4001;
const long LJ_chSTREAM_CLOCK_OUTPUT = 4002;
const long LJ_chSTREAM_EXTERNAL_TRIGGER = 4003;
const long LJ_chSTREAM_WAIT_MODE = 4004;
// readonly stream related
const long LJ_chSTREAM_BACKLOG_COMM = 4105;
const long LJ_chSTREAM_BACKLOG_CONTROL = 4106;
const long LJ_chSTREAM_BACKLOG_UD = 4107;
// special channel #'s
const long LJ_chALL_CHANNELS = -1;
const long LJ_INVALID_CONSTANT = -999;
// other constants:
// ranges (not all are supported by all devices):
const long LJ_rgBIP20V = 1;  // -20V to +20V
const long LJ_rgBIP10V = 2;  // -10V to +10V
const long LJ_rgBIP5V = 3;   // -5V to +5V
const long LJ_rgBIP4V = 4;   // -4V to +4V
const long LJ_rgBIP2P5V = 5; // -2.5V to +2.5V
const long LJ_rgBIP2V = 6;   // -2V to +2V
const long LJ_rgBIP1P25V = 7;// -1.25V to +1.25V
const long LJ_rgBIP1V = 8;   // -1V to +1V
const long LJ_rgBIPP625V = 9;// -0.625V to +0.625V
const long LJ_rgUNI20V = 101;  // 0V to +20V
const long LJ_rgUNI10V = 102;  // 0V to +10V
const long LJ_rgUNI5V = 103;   // 0V to +5V
const long LJ_rgUNI4V = 104;   // 0V to +4V
const long LJ_rgUNI2P5V = 105; // 0V to +2.5V
const long LJ_rgUNI2V = 106;   // 0V to +2V
const long LJ_rgUNI1P25V = 107;// 0V to +1.25V
const long LJ_rgUNI1V = 108;   // 0V to +1V
const long LJ_rgUNIP625V = 109;// 0V to +0.625V
const long LJ_rgUNIP500V = 110; // 0V to +0.500V
const long LJ_rgUNIP3125V = 111; // 0V to +0.3125V
// timer modes (UE9 only):
const long LJ_tmPWM16 = 0; // 16 bit PWM
const long LJ_tmPWM8 = 1; // 8 bit PWM
const long LJ_tmRISINGEDGES32 = 2; // 32-bit rising to rising edge measurement
const long LJ_tmFALLINGEDGES32 = 3; // 32-bit falling to falling edge measurement
const long LJ_tmDUTYCYCLE = 4; // duty cycle measurement
const long LJ_tmFIRMCOUNTER = 5; // firmware based rising edge counter
const long LJ_tmFIRMCOUNTERDEBOUNCE = 6; // firmware counter with debounce
const long LJ_tmFREQOUT = 7; // frequency output
const long LJ_tmQUAD = 8; // Quadrature
const long LJ_tmTIMERSTOP = 9; // stops another timer after n pulses
const long LJ_tmSYSTIMERLOW = 10; // read lower 32-bits of system timer
const long LJ_tmSYSTIMERHIGH = 11; // read upper 32-bits of system timer
const long LJ_tmRISINGEDGES16 = 12; // 16-bit rising to rising edge measurement
const long LJ_tmFALLINGEDGES16 = 13; // 16-bit falling to falling edge measurement
// timer clocks:
const long LJ_tc750KHZ = 0;   // UE9: 750 khz 
const long LJ_tcSYS = 1;      // UE9: system clock
const long LJ_tc2MHZ = 10;     // U3
const long LJ_tc6MHZ = 11;     // U3
const long LJ_tc24MHZ = 12;     // U3
const long LJ_tc500KHZ_DIV = 13;// U3
const long LJ_tc2MHZ_DIV = 14;  // U3
const long LJ_tc6MHZ_DIV = 15;  // U3
const long LJ_tc24MHZ_DIV = 16; // U3
// stream wait modes
const long LJ_swNONE = 1;  // no wait, return whatever is available
const long LJ_swALL_OR_NONE = 2; // no wait, but if all points requested aren't available, return none.
const long LJ_swPUMP = 11;  // wait and pump the message pump.  Prefered when called from primary thread (if you don't know
// if you are in the primary thread of your app then you probably are.  Do not use in worker
// secondary threads (i.e. ones without a message pump).
const long LJ_swSLEEP = 12; // wait by sleeping (don't do this in the primary thread of your app, or it will temporarily 
// hang)  This is usually used in worker secondary threads.
// error codes:  These will always be in the range of -1000 to 3999 for labView compatibility (+6000)
const LJ_ERROR LJE_NOERROR = 0;
const LJ_ERROR LJE_INVALID_CHANNEL_NUMBER = 2; // occurs when a channel that doesn't exist is specified (i.e. DAC #2 on a UE9), or data from streaming is requested on a channel that isn't streaming
const LJ_ERROR LJE_INVALID_RAW_INOUT_PARAMETER = 3;
const LJ_ERROR LJE_UNABLE_TO_START_STREAM = 4;
const LJ_ERROR LJE_UNABLE_TO_STOP_STREAM = 5;
const LJ_ERROR LJE_NOTHING_TO_STREAM = 6;
const LJ_ERROR LJE_UNABLE_TO_CONFIG_STREAM = 7;
const LJ_ERROR LJE_BUFFER_OVERRUN = 8; // occurs when stream buffer overruns (this is the driver buffer not the hardware buffer).  Stream is stopped.
const LJ_ERROR LJE_STREAM_NOT_RUNNING = 9;
const LJ_ERROR LJE_INVALID_PARAMETER = 10;
const LJ_ERROR LJE_INVALID_STREAM_FREQUENCY = 11; 
const LJ_ERROR LJE_INVALID_AIN_RANGE = 12;
const LJ_ERROR LJE_STREAM_CHECKSUM_ERROR = 13; // occurs when a stream packet fails checksum.  Stream is stopped
const LJ_ERROR LJE_STREAM_COMMAND_ERROR = 14; // occurs when a stream packet has invalid command values.  Stream is stopped.
const LJ_ERROR LJE_STREAM_ORDER_ERROR = 15; // occurs when a stream packet is received out of order (typically one is missing).  Stream is stopped.
const LJ_ERROR LJE_AD_PIN_CONFIGURATION_ERROR = 16; // occurs when an analog or digital request was made on a pin that isn't configured for that type of request
const LJ_ERROR LJE_REQUEST_NOT_PROCESSED = 17; // When a LJE_AD_PIN_CONFIGURATION_ERROR occurs, all other IO requests after the request that caused the error won't be processed. Those requests will return this error.
// U3 Specific Errors
const LJ_ERROR LJE_SCRATCH_ERROR = 19;
const LJ_ERROR LJE_DATA_BUFFER_OVERFLOW = 20;
const LJ_ERROR LJE_ADC0_BUFFER_OVERFLOW = 21; 
const LJ_ERROR LJE_FUNCTION_INVALID = 22;
const LJ_ERROR LJE_SWDT_TIME_INVALID = 23;
const LJ_ERROR LJE_FLASH_ERROR = 24;
const LJ_ERROR LJE_STREAM_IS_ACTIVE = 25;
const LJ_ERROR LJE_STREAM_TABLE_INVALID = 26;
const LJ_ERROR LJE_STREAM_CONFIG_INVALID = 27;
const LJ_ERROR LJE_STREAM_BAD_TRIGGER_SOURCE = 28;
const LJ_ERROR LJE_STREAM_INVALID_TRIGGER = 30;
const LJ_ERROR LJE_STREAM_ADC0_BUFFER_OVERFLOW = 31;
//const LJ_ERROR LJE_STREAM_SCAN_OVERLAP = 32;
const LJ_ERROR LJE_STREAM_SAMPLE_NUM_INVALID = 33;
const LJ_ERROR LJE_STREAM_BIPOLAR_GAIN_INVALID = 34;
const LJ_ERROR LJE_STREAM_SCAN_RATE_INVALID = 35;
const LJ_ERROR LJE_TIMER_INVALID_MODE = 36;
const LJ_ERROR LJE_TIMER_QUADRATURE_AB_ERROR = 37;
const LJ_ERROR LJE_TIMER_QUAD_PULSE_SEQUENCE = 38;
const LJ_ERROR LJE_TIMER_BAD_CLOCK_SOURCE = 39;
const LJ_ERROR LJE_TIMER_STREAM_ACTIVE = 40;
const LJ_ERROR LJE_TIMER_PWMSTOP_MODULE_ERROR = 41;
const LJ_ERROR LJE_TIMER_SEQUENCE_ERROR = 42;
const LJ_ERROR LJE_TIMER_SHARING_ERROR = 43;
const LJ_ERROR LJE_TIMER_LINE_SEQUENCE_ERROR = 44;
const LJ_ERROR LJE_EXT_OSC_NOT_STABLE = 45;
const LJ_ERROR LJE_INVALID_POWER_SETTING = 46;
const LJ_ERROR LJE_PLL_NOT_LOCKED = 47;
const LJ_ERROR LJE_INVALID_PIN = 48;
const LJ_ERROR LJE_IOTYPE_SYNCH_ERROR = 49;
const LJ_ERROR LJE_INVALID_OFFSET = 50;
const LJ_ERROR LJE_FEEDBACK_IOTYPE_NOT_VALID = 51;
const LJ_ERROR LJE_SHT_CRC = 52;
const LJ_ERROR LJE_SHT_MEASREADY = 53;
const LJ_ERROR LJE_SHT_ACK = 54;
const LJ_ERROR LJE_SHT_SERIAL_RESET = 55;
const LJ_ERROR LJE_SHT_COMMUNICATION = 56;
const LJ_ERROR LJE_AIN_WHILE_STREAMING = 57;
const LJ_ERROR LJE_STREAM_TIMEOUT = 58;
const LJ_ERROR LJE_STREAM_CONTROL_BUFFER_OVERFLOW = 59;
const LJ_ERROR LJE_STREAM_SCAN_OVERLAP = 60;
const LJ_ERROR LJE_MIN_GROUP_ERROR = 1000; // all errors above this number will stop all requests, below this number are request level errors.
const LJ_ERROR LJE_UNKNOWN_ERROR = 1001; // occurs when an unknown error occurs that is caught, but still unknown.
const LJ_ERROR LJE_INVALID_DEVICE_TYPE = 1002; // occurs when devicetype is not a valid device type
const LJ_ERROR LJE_INVALID_HANDLE = 1003; // occurs when invalid handle used
const LJ_ERROR LJE_DEVICE_NOT_OPEN = 1004;  // occurs when Open() fails and AppendRead called despite.
const LJ_ERROR LJE_NO_DATA_AVAILABLE = 1005; // this is cause when GetData() called without calling DoRead(), or when GetData() passed channel that wasn't read
const LJ_ERROR LJE_NO_MORE_DATA_AVAILABLE = 1006;
const LJ_ERROR LJE_LABJACK_NOT_FOUND = 1007; // occurs when the labjack is not found at the given id or address.
const LJ_ERROR LJE_COMM_FAILURE = 1008; // occurs when unable to send or receive the correct # of bytes
const LJ_ERROR LJE_CHECKSUM_ERROR = 1009;
const LJ_ERROR LJE_DEVICE_ALREADY_OPEN = 1010; 
const LJ_ERROR LJE_COMM_TIMEOUT = 1011;
const LJ_ERROR LJE_USB_DRIVER_NOT_FOUND = 1012;
const LJ_ERROR LJE_INVALID_CONNECTION_TYPE = 1013;
const LJ_ERROR LJE_INVALID_MODE = 1014;
// warning are negative
const LJ_ERROR LJE_DEVICE_NOT_CALIBRATED = -1; // defaults used instead
const LJ_ERROR LJE_UNABLE_TO_READ_CALDATA = -2; // defaults used instead
*/
/* version history:
2.02: ain_binary fixed for non-streaming
adjusted for new streaming usb firmware (64byte packets)
new streaming errors- stop the stream and error is returned with next GetData
fixed resolution setting while streaming (was fixed to 12, now follows poll setting)
2.03: added callback option for streaming
2.04: changed warnings to be negative. 
renamed POWER_LEVEL to COMM_POWER_LEVEL
2.05: updated timer/counter stuff,  Added CounterReset, TimerClockDivisor.
2.06: fixed problem when unplugging USB UE9 and plugging it into a different USB port
renamed LJ_chCOUNTERTIMER_CLOCK to LJ_chTIMER_CLOCK_CONFIG
2.08: fixed two UE9 USB unplug issue, 
driver now uses high temp calibration for Control power level zero
added new timer modes to header
fixed LJ_tcSYS constant in header.
2.09: new timer constants for new modes
timer/counter update bits auto-setting updated
put_counter_reset will execute with the next go, not only with the next read
2.10: timer/counter update bits auto-setting updated again
fixed MIO bits as outputs
listall()
fixed control power level and reset source
added ioDIGITAL_PORT_IN and ioDIGITAL_PORT_OUT
2.11: fixed problem with ListAll when performed without prior opening of devices
2.12: added initial raw U3 support
2.13: fixed issues with streaming backlog and applying cals to extended channels.
2.14: fixed issue with U3 raw support
2.15: fixed driver issue with stream clock output and stream external triggering
2.16: fixed problem with listall after changing local id
2.17: fixed issues with streaming backlog and applying cals to extended channels.
fixed problem with usb reset, added timer mode 6 to header file
2.18: fixed issue with rollover on counter/timer
fixed reset issues
2.21: UE9 changed to use feedbackalt instead of feedback.  Allows for multiple 
internal channels to be called from same call to feedback.
fixed internal channel numbers 14/128 and 15/136 and extended channels
to return proper values. 
2.22: fixed problem with ioGET_TIMER when passed as a string.  Added support for 
make unlimited number of requests for analog input chanels for a single 
call to a go function
2.23: 
2.24: fixed bug sometimes causing errors when a pointer was passed into the Raw 
io functions that caused a communication error
2.25: improved U3 support
2.26: fixed U3 bugs with timer/counter values, DAC rounding and set analog 
enabled port functions
2.46: Various U3 fixes and support added
2.47: Fixed threading issue
2.48: Added LJ_ioPUT_WAIT
*/
/*
// depreciated constants:
const long LJ_ioANALOG_INPUT = 10;  
const long LJ_ioANALOG_OUTPUT = 20; // UE9 + U3
const long LJ_ioDIGITAL_BIT_IN = 30; // UE9 + U3
const long LJ_ioDIGITAL_PORT_IN = 35; // UE9 + U3 
const long LJ_ioDIGITAL_BIT_OUT = 40; // UE9 + U3
const long LJ_ioDIGITAL_PORT_OUT = 45; // UE9 + U3
const long LJ_ioCOUNTER = 50; // UE9 + U3
const long LJ_ioTIMER = 60; // UE9 + U3
const long LJ_ioPUT_COUNTER_MODE = 2010; // UE9
const long LJ_ioGET_COUNTER_MODE = 2011; // UE9
const long LJ_ioGET_TIMER_VALUE = 2007; // UE9
const long LJ_ioCYCLE_PORT = 102;  // UE9 
const long LJ_chTIMER_CLOCK_CONFIG = 1001; // UE9 + U3 // depr
*/
#ifdef  __cplusplus
} // extern C
#endif
#endif
