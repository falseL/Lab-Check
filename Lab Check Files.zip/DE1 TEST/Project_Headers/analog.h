#ifndef ANALOG_H
#define ANALOG_H

#define SPIRxInt  	0x10		// SPI interrupt operation enabled
/*#define SPIdac		0x01		// SPI dac
#define SPIadc		0x02		// SPI used by adc
#define SPIext		0x04		// SPI used by external device
#define SPIrxDone	0x80		// SPI 16 bit data received
#define SPIsecond	0x40		// SPI waiting for second interrupt
*/

#define   DACtime   (20 * 20)/8   // 20 us for DAC output
#define   ADCtime   (80 * 20)/8   // 80 us for ADC conversion

void ANALOGopen(unsigned char RxInt);
void ANALOGclose(void);
unsigned int ADCgetSample(char chan);
void DACoutSample(char chan, int sample);
void ADCstart(char chan);

#endif	// ANALOG_H