#include <hidef.h> /* for EnableInterrupts macro */
#include "derivative.h" /* include peripheral declarations */
#include <stdlib.h>
#include "keypad.h"
#include "lcd.h"
#include "analog.h"
#include "serial.h"

void TestDisplay(char Test);
int ob12toi(unsigned int val);
void CodeToVolts(int code, char *s);

/*
   Hex to 7 segment display

 */
const unsigned char Seg7Table[16] =
{
  0xFC,   // 0  =  1111_1100
  0x60,   // 1  =  0110_0000
  0xDA,   // 2  =  1101_1010
  0xF2,   // 3  =  1111_0010
  0x66,   // 4  =  0110_0110
  0xB6,   // 5  =  1011_0110
  0xBE,   // 6  =  1011_1110
  0xE0,   // 7  =  1110_0000
  0xFE,   // 8  =  1111_1110
  0xF6,   // 9  =  1111_0110
  0xEE,   // A  =  1110_0110
  0x3E,   // B  =  0011_1110
  0x9C,   // C  =  1001_1100
  0x7A,   // D  =  0111_1010
  0x9E,   // E  =  1001_1110
  0x8E    // F  =  1000_1110
};

#pragma DATA_SEG __SHORT_SEG _DATA_ZEROPAGE
unsigned char i, j, k, x;
unsigned int obval;
int sval, sval1;

#pragma DATA_SEG DEFAULT

char buf[10];


void main(void)
{
  unsigned char Test, ch;

	SOPT_COPE = 0;	/* disable COP */
  /* include your code here */
  TPM2SC = 0x0B;
  KPopen();
  LCDopen();
  ANALOGopen(0);
  SCI2open(19200,0);

  EnableInterrupts; /* enable interrupts */

  for( ; ; ) {
    while (!TPM2SC_TOF) { }
    Test = SWL & 0x07;
    TestDisplay(Test);
    switch (Test) {
      case 0:
        HEX0 = 0xFF;
        HEX1 = 0xFF;
        HEX2 = 0xFF;
        break;
      case 1:   // keypad testing
        HEX1 = 0xFF;
        HEX2 = 0xFF;
        if (KPhit()) {
          ch = KPgetch();
          LCDline(3);
          LCDputch(ch);
          if (ch == '*')
            ch = 0x0E;
          else if (ch == '#')
            ch = 0x0F;
          else if (ch <= '9')
            ch = ch - '0';
          else
            ch = ch - 'A' + 0x0A;
          HEX0 = ~Seg7Table[ch];
        }
        break;
      case 2:    // LCD testing
        HEX0 = 0xFF;
        HEX1 = 0xFF;
        HEX2 = 0xFF;
/*        x++;
        if (x > 38) {   // 1 second
          x = 0;
*/
        if ((j < 2) || (j > 4)) {
          j = 2;
          LCDclear(2);
        }
				if (KPhit()) {
					KPflush();
          for (i = 0; i < 16; i++) {
//             if ((k >= 0x80)||(k < 0x20))
             if ((k >= 0xFE)||(k < 0x20))
                k = 0x20;
             else if ((k >= 0x80)&&(k < 0xA0))
                k = 0xA0;
              
             LCDputch(k);
             k++;
          }
          j++;
          if (j > 4)
            j = 2;
          LCDclear(j);
        }
        break;
      case 3:         // DAC test
        LCDinstruct(LCDcursorOFF);
        while (ch != '*') {
          if (TPM2SC_TOF) {
            TPM2SC_TOF = 0;
            x++;
            if (x > 38) {   // 1 second
              x = 0;
              obval = SWL << 4;
              DACoutSample(1, obval);
              LCDclear(2);
              (void)_itoa(obval, buf, 10);
              LCDputs("DAC code ");
              LCDputs(buf);
              SCI2puts("DAC code = ");
              SCI2puts(buf);
              sval = ob12toi(obval);
              CodeToVolts(sval,buf);
              LCDline(3);
              LCDputs("DAC = ");
              LCDputs(buf);
              LCDputs("V  ");
              SCI2puts("\r\nDAC output = ");
              SCI2puts(buf);
              SCI2puts(" Volts\r\n");
            }
          }
          if (KPhit()) ch = KPgetch();
        }
        LCDinstruct(LCDcursorON);
        ch = 0;
        break;
      case 4:         // ADC test
        LCDinstruct(LCDcursorOFF);
        while (ch != '*') {
          if (TPM2SC_TOF) {
            TPM2SC_TOF = 0;
            x++;
            if (x > 38) {   // 1 second
              x = 0;
              obval = ADCgetSample(1);
              LCDline(3);
              (void)_itoa(obval, buf, 10);
              LCDputs("ADC code ");
              LCDputs(buf);
              SCI2puts("ADC code = ");
              SCI2puts(buf);
              sval = ob12toi(obval);
              CodeToVolts(sval,buf);
              LCDline(3);
              LCDputs("ADC = ");
              LCDputs(buf);
              LCDputs("V  ");
              SCI2puts("ADC input = ");
              SCI2puts(buf);
              SCI2puts(" Volts\r\n");
            }
          }
          if (KPhit()) ch = KPgetch();
        }
        LCDinstruct(LCDcursorON);
        ch = 0;
        break;
      case 5:         // DAC - ADC test
        LCDinstruct(LCDcursorOFF);
        while (ch != '*') {
          if (TPM2SC_TOF) {
            TPM2SC_TOF = 0;
            x++;
            if (x > 38) {   // 1 second
              x = 0;
              obval = SWL << 4;
              DACoutSample(1, obval);
              sval = ob12toi(obval);
              CodeToVolts(sval,buf);
              LCDclear(2);
              LCDputs("DAC = ");
              LCDputs(buf);
              LCDputs("V  ");
              SCI2puts("DAC output = ");
              SCI2puts(buf);
              SCI2puts(" Volts\r\n");

              obval = ADCgetSample(1);
              sval1 = ob12toi(obval);
              CodeToVolts(sval1,buf);
              LCDclear(3);
              LCDputs("ADC = ");
              LCDputs(buf);
              LCDputs("V  ");
              SCI2puts("ADC input = ");
              SCI2puts(buf);
              SCI2puts(" Volts\r\n");

              sval -= sval1;
              (void)_itoa(sval,buf,10);
              LCDclear(4);
              LCDputs("Err = ");
              LCDputs(buf);
              LCDputs("mV");
              SCI2puts("Err = ");
              SCI2puts(buf);
              SCI2puts("mV\r\n");

            }
          }
          if (KPhit()) ch = KPgetch();
        }
        LCDinstruct(LCDcursorON);
        ch = 0;
        break;
      default:
        break;
    }

  } /* loop forever */
  /* please make sure that you never leave main */
}

const char *TestStr[] = {
  "No test selected",
  "Keypad Test",
  "LCD Test",
  "DAC Test",
  "ADC Test",
  "DAC to ADC Test",
  "TBD",
  "TBD"
};

void TestDisplay(char Test){
#pragma DATA_SEG __SHORT_SEG _DATA_ZEROPAGE
  static char currTest;
#pragma DATA_SEG DEFAULT

  LEDG = Test;
  HEX3 = ~Seg7Table[Test];
  if (Test != currTest) {
    HEX0 = 0xFF;
    currTest = Test;
    LCDclear(0);
    LCDputs(TestStr[currTest]);
    SCI2puts("\r\n");
    SCI2puts(TestStr[currTest]);
    SCI2puts("\r\n");
  }
}

/***************************************************************************
 *
 * ob12toi
 *
 *  12 bit offset binary to integer conversion
 *
*/
int ob12toi(unsigned int val)
{
  unsigned char *p;

  p = (unsigned char *)&val; // pointer to upper byte
  if (*p & 0x08)  // positive
    *p &= 0x07;
  else
    *p |= 0xF8;
  return val;
}

/***************************************************************************
 *
 * CodeToVolts
 *
*/
void CodeToVolts(int code, char *s)
{
  signed char whole;
  int fract;
  long temp;

  temp = code * 5000L;  // convert to millivolts
  temp += 1024;         // round
  code = (temp >> 11) & 0xFFFF;

  if (code < 0) {
    code = -code;
    *s++ = '-';
  }
  whole = code/1000;  // integer volts
  fract = code % 1000;
  (void)_itoa(whole, s, 10);

  while (*s) s++;
  *s++ = '.';        // decimal point
  code = fract / 100;  // tenths digit
  fract %= 100;
  *s++ = code + '0'; // convert to ASCII
  code = fract / 10;  // hundredths digit
  fract %= 10;
  *s++ = code + '0'; // convert to ASCII
  *s++ = fract + '0'; // thousandths digit
  *s = 0;
}

