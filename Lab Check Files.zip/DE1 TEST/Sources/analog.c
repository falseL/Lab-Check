/*
    File        : analog.c
    Project   : MCO556
    Author    : G. VandeBelt
    Created   : 2012/03/03


 */
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"	 /* derivative information */
#include "analog.h"     // function prototypes for analog driver


#define SPI1C1_init (0b01011110)
//                     ||||||||
//                     |||||||+--  LSBFE  - MSB first
//                     ||||||+---  SSOE   - Automatic SS output
//                     |||||+----  CPHA   - sample on rising edge
//                     ||||+-----  CPOL   - clock idles high
//                     |||+------  MSTR   - master mode
//                     ||+-------  SPTIE  - no Rx interrupts
//                     |+--------  SPE    - module enabled
//                     +---------  SPIE   - no Rx interrupts
#define SPI1C2_init (0b00010000)
//                     ||||||||
//                     |||||||+--  CPC0    	- separate pins for in and output
//                     ||||||+---  SPISWAI 	- clocks continue in wait
//                     |||||+----  0      	- unused
//                     ||||+-----  BIDIROE	- 0 -
//                     |||+------  MODFEN 	- Automatic SS output
//                     ||+-------  DEV0		- 00 = ADC channel 0	01 = ADC channel 1
//                     |+--------  DEV1		- 10 = DAC channels		11 = external SPI dev1ce
//                     +---------  0      	- unused

// locate ADC control on page zero
#pragma DATA_SEG __SHORT_SEG  _DATA_ZEROPAGE
static unsigned char  SPIflags;
#define SPIdac		0x01		// SPI dac
#define SPIadc		0x02		// SPI used by adc
#define SPIext		0x04		// SPI used by external device
// #define SPIRxInt  	0x10		// SPI interrupt operation enabled
#define SPIsecond	0x40		// SPI waiting for second interrupt
#define SPIrxDone	0x80		// SPI receive done

#define SPItime	   0x20		   // timer used for ADC conversion
// #define SPIcomplete	   0x20		   // timer used for ADC conversion

// #define   DACtime   (20 * 20)/8   // 20 us for DAC output
// #define   ADCtime   (80 * 20)/8   // 80 us for ADC conversion


static union
{
        unsigned int w;
        unsigned char b[2];
} ADCdata;
#pragma DATA_SEG DEFAULT

#define ADCdataH  	ADCdata.b[0]
#define ADCdataL 	ADCdata.b[1]
#define ADCdataW 	ADCdata.w
//
//	Configure SPI module
//
//	Set Baud rate to 10 MHz
//
//
void ANALOGopen(unsigned char RxInt)
{
	PTEDD = 0x00;		// set PTE pins as inputs - can be read
	SPI1BR = 0;			// 10 MHz - bus clock / 2
	SPI1C2 = SPI1C2_init;
	SPI1C1 = SPI1C1_init;
	if (RxInt) SPIflags = SPIRxInt;
	else SPIflags = 0;
}

void ANALOGclose(void)
{
	SPI1C2 = 0;
	SPI1C1 = 0;
     SPIflags = 0;
}
//
//	DAC operation (SPI may be interrupt driven for ADC)
//
void DACoutSample(char chan, int sample)
{
	unsigned char x;

	if (SPIflags & SPIadc)		// SPI in use by ADC?
		return;
	// wait for any previous transaction to complete
	while ((PTED & 0xC6) != 0xC6) {}	// wait for SPI idle - all SS lines HIGH

	while (SPI1S_SPRF)
		x = SPI1D;			// clear SPI receive buffer

	SPI1BR = 0x00;		// 10 MHz - bus clock / 2
	SPI1C1_SPIE = 0;					// disable - Rx interrupts
	SPI1C2 = SPI1C2_init | (2 << 6) ;	// select DAC device
	x = 0x0F & (sample >> 8);

	if (chan == 0)
		x |= 0x70;	// ch A, buffered, gain = 1, active mode
	else
		x |= 0xF0;	// ch B, buffered, gain = 1, active mode
	while (!SPI1S_SPTEF) ;		// wait for Tx empty
    DisableInterrupts;
	SPI1D = x;	// send MSB
	while (!SPI1S_SPTEF) ;		// wait for Tx empty
	SPI1D = sample & 0xFF;		// send LSB
    EnableInterrupts;
}

void ADCstart(char chan)
{  char x;

	if (!(SPIflags & SPIRxInt))
		return;				// not interrupt driven ADC - exit
	while ((PTED & 0xC6) != 0xC6) {}	// wait for SPI idle - all SS lines HIGH

	while (SPI1S_SPRF)
		x = SPI1D;			// clear SPI receive buffer

 	SPIflags = SPIadc | SPIRxInt ;	// mark SPI used by ADC using interrupts
	SPI1C1_SPIE = 1;		// enable - Rx interrupts

	SPI1BR = 0x61;				// 714 kHz - bus clock / 28
	if (chan == 0)
		SPI1C2 = SPI1C2_init;				// select ADC0
	else
		SPI1C2 = SPI1C2_init | (1 << 6);	// select ADC 1
    DisableInterrupts;
	SPI1D = 0xFF;
	while (!SPI1S_SPTEF) ;		// wait for Tx empty
	SPI1D = 0xFF;
    EnableInterrupts;
	ADCdataW = 0;				// clear ADC result
}

unsigned int ADCgetSample(char chan)
{
	unsigned int x;

	while ((PTED & 0xC6) != 0xC6) {}	// wait for SPI idle - all SS lines HIGH
	while (SPI1S_SPRF)
		x = SPI1D;			// clear SPI receive buffer

	if (SPIflags & SPIRxInt) {
		SPIflags = SPIRxInt;		// clear ADC flags
		return ADCdataW;			// return interrupt data
	}

	// non-interrupt driven
	SPI1BR = 0x61;				// 714 kHz - bus clock / 28
	if (chan == 0)
		SPI1C2 = SPI1C2_init;				// select ADC0
	else
		SPI1C2 = SPI1C2_init | (1 << 6);	// select ADC 1
	SPI1C1_SPIE = 0;			// disable - Rx interrupts

	// generate 16 clocks to get ADC data
    DisableInterrupts;
	SPI1D = 0xFF;
	while (!SPI1S_SPTEF) ;		// wait for Tx empty
	SPI1D = 0xFF;
    EnableInterrupts;
	while (!SPI1S_SPRF) ;		// wait for Rx full
	x = (SPI1D & 0x1F) << 8;

	while (!SPI1S_SPRF) ;		// wait for Rx full
	x |= SPI1D;
	x >>= 1;
	return x;
}

//
//		SPI receive interrupt for ADC and DAC operation
//
interrupt void SPIisr(void)
{
	unsigned char x;

	x = SPI1S;		// read status
	x = SPI1D;		// get data and clear interrupt
	if (SPIflags & SPIsecond) {
		SPI1C1_SPIE = 0;	// disable interrupts
		ADCdataL = x;
		ADCdataW >>= 1;
		SPIflags &= ~SPIadc;	// clear SPI in use by ADC
	} else {
		SPIflags |= SPIsecond; // set waiting for second byte
		ADCdataH = x & 0x1F;
	}
}

interrupt void TPM2C0isr(void)
{
  unsigned char x;
  if (SPIflags & SPItime)       // ADC input time
  {
	SPIflags = SPIadc | SPIRxInt;		// mark SPI used by ADC using interrupts
	SPI1BR = 0x61;				// 714 kHz - bus clock / 28
	SPI1C2 = SPI1C2_init | (1 << 6);	// select ADC 1
    x = SPI1S;        // prime status flags
    x = SPI1D;        // clear SPIF
	SPI1D = 0xFF;
    TPM2C0V += ADCtime;
    TPM2C0SC_CH0F = 0;
	while (!SPI1S_SPTEF) ;		// wait for Tx empty
	SPI1D = 0xFF;
	ADCdataW = 0;				// clear ADC result
	SPI1C1_SPIE = 1;					// enable - Rx interrupts
    SPIflags &= ~SPItime;
  } else
  {         // output a sample
	SPI1BR = 0x00;	    	// 10 MHz - bus clock / 2
	SPI1C2 = SPI1C2_init | (2 << 6);	// select DAC device
 	 x = (SWL << 4) & 0xFF;
	while (!SPI1S_SPTEF) ;		// wait for Tx empty
    SPI1D = 0xF0 | ((SWL >> 4) & 0xFF);
    TPM2C0SC_CH0F = 0;
	 while (!SPI1S_SPTEF) ;		// wait for Tx empty
 	 SPI1D = x;
    TPM2C0V += DACtime;
    SPIflags |= SPItime;
  }
}
